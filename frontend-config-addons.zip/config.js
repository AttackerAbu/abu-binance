// Drop this <script> before your main script in index.html
// Set to your deployed backend
window.API_BASE_HTTP = ""; // e.g., "https://ai-bot-api.onrender.com"
window.API_BASE_WS = "";   // e.g., "wss://ai-bot-api.onrender.com/ws";
